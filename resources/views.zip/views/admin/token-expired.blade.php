<div style="margin:30px auto; border:1px solid #e0e1e2; width:80%;">
	<h3 style="color:#333; background:rgb(242,242,242); border-bottom:1px solid #e0e1e2; margin:0; padding:5px;" >Error!</h3>
	<p style="margin: 10px 15px 5px;"><strong>Your Token has been expired.</strong></p>
    <p style="margin: 5px 15px 10px;">If the problem persists, please try again after clearing the Temporary Files from your web browser.</p>
</div>