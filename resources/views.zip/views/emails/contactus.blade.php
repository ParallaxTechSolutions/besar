<div style="padding:0px; margin:0px;">
    <table width="1000" border="0" align="center" cellpadding="0" cellspacing="0" style="padding:10px; background:#fff;">

        <tr>
            <td width="550" align="left" valign="top" style="border-bottom:1px solid #ccc; padding:10px 0 20px;"><h2 style="padding:0px; margin:0px; color:#444645; font-size:32px;">User Contact Us Notification</h2></td>
            <td width="450" align="right" valign="top" style="border-bottom:1px solid #ccc; padding:10px 0 20px;"><h2 style="padding:0px; margin:0px; color:#444645; font-size:32px;"></h2></td>
        </tr>
        <tr>
        	<td colspan="2" align="left" valign="top">&nbsp;</td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>First Name:</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Last Name:</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['first_name']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['last_name']}}</td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Company Name:</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Occupation:</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['company_name']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['occupation']}}</td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Telephone:</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Fax:</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['tel']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['fax']}}</td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Email</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Address</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['email']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['Address']}}</td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>City</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Postal Code</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['city']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['postcode']}}</td>
        </tr>
        
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Room</strong></td>
        	<td align="right" valign="top" style="color:#646464; font-size:20px; padding:5px 0; margin:0px;"><strong>Subject</strong></td>
        </tr>
        <tr>
        	<td align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['room']}}</td>
        	<td align="right" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['subject']}}</td>
        </tr>

        <tr>
        	<td colspan="2" align="left" valign="top" style=" padding:0px 0 0; margin:0 0 0px;"><h2 style="padding:10px 0; margin:0px; color:#444645; font-size:22px;">Comment Inquiry</h2></td>
        </tr>
        <tr>
        	<td colspan="2" align="left" valign="top" style="color:#646464; font-size:14px; padding:3px 0; margin:0px;">{{ $contact['comment_enquiry']}}</td>
        </tr>

        <tr>
			<td colspan="6">&nbsp;</td>
        </tr>
        <tr>
			<td colspan="6" align="center"><strong>Note: This document is computer generated and no signature is requied.</strong></td>
        </tr>

    </table>
</div>