<div style="margin:15px">
    <h4>Dear {{$formData['billing_first_name']}},</h4>

    <p>This is confirmation for the successful e-news subscription with Tower Regency Hotel And Apartments.</p>
    <p>You have now been added to the mailing list and will receive the next email information in the coming days or weeks.
        If you ever wish to unsubscribe, simply use the unsubscribe link included in each newsletter. We're excited that we'll have you as a customer soon!
        In the meantime, come and like us on Facebook!</p>

    <p>https://www.facebook.com/Towerreg</p>
    <img alt="logo" src="{{$formData['url']}}">
    <p>Thank you again for signing up!</p>
    Best regards,<br>
    Tower Regency Hotel And Apartments Online Registration Manager<br>
    Tower Regency Hotel And Apartments<br>
    6, Jalan Dato Seri Ahmad Said, 30450 Ipoh, Perak, Malaysia.<br>
    Tel: (05) 208-6888<br>
    Fax: (603) 255-8399<br>
    inquiry@towerregency.com.my<br>
</div>