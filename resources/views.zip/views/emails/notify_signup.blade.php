<div style="margin:15px">
    <h4>Dear Admin,</h4>
    <p>New signup for notification:</p>
    <br>
    <p>Email: {{ $email }}</p>
    <p>Item ID: {{ $product_id }}</p>
    <p>Check In Date: {{ $checkin_date }}</p>
    <p>Check Out Date: {{ $checkout_date }}</p>
    <p>Room: {{ $room }}</p>
    <p>Adult: {{ $adult }}</p>
    <p>Children: {{ $children }}</p>
    
    
    <p>Thank you,</p>
    Best regards,<br>
    Tower Regency Hotel And Apartments Online Registration Manager<br>
    Tower Regency Hotel And Apartments<br>
    6, Jalan Dato Seri Ahmad Said, 30450 Ipoh, Perak, Malaysia.<br>
    Tel: (05) 208-6888<br>
    Fax: (603) 255-8399<br>
    inquiry@towerregency.com.my<br>

</div>