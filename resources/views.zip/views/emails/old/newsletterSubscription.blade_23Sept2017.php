<div style="margin:15px">
    <h4>Dear {{$formData['billing_first_name']}},</h4>
    <br><br>
    <p>This is confirmation for the successful e-news subscription with TBM.</p><br><br>
<p>You have now been added to the mailing list and will receive the next email information in the coming
days or weeks. If you ever wish to unsubscribe, simply use the unsubscribe link included in each
newsletter. We're excited that we'll have you as a customer soon!
In the meantime, come and like us on Facebook!</p><br><br>

		<p>https://www.facebook.com/tbm2u</p><br><br>

		<p>Thanks again for signing up!</p><br><br>

		Thank you,<br>
		Best regards,<br>
		TBM Online Registration Manager<br>
		TAN BOON MING SDN BHD (494355-D)<br>
		PS 4,5,6 & 7, Taman Evergreen, Batu 4, Jalan Klang Lama, 58100 Kuala Lumpur.<br>
		Tel: (603) 7983-2020 (Hunting Lines)<br>
		Fax: (603) 7982-8141<br>
		info@tbm.com.my<br>
		Business Hours:<br>
		Mon. - Sat.: 9.30am - 9.00pm<br>
		Sun.: 10.00am - 9.00pm <br/>
    
</div>