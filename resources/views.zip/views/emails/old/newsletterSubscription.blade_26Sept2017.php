<div style="margin:15px">
    <h4>Dear {{$formData['billing_first_name']}},</h4>

    <p>This is confirmation for the successful e-news subscription with Ritz Garden Hotel Ipoh.</p>
<p>You have now been added to the mailing list and will receive the next email information in the coming days or weeks.
If you ever wish to unsubscribe, simply use the unsubscribe link included in each newsletter. We're excited that we'll have you as a customer soon!
In the meantime, come and like us on Facebook!</p>

		<p>https://www.facebook.com/RitzGardenHotelIpoh/</p>
                <img alt="logo" src="http://www4.ritzgardenhotel.com/public/front/images/index/logo.png">
		<p>Thank you again for signing up!</p>
                Best regards,<br>
                Ritz Garden Hotel Online Registration Manager<br>
                Ritz Garden Hotel<br>
                No. 86 & 88, Jalan Yang Kalsom, 30250 Ipoh Perak Darul Ridzuan, Malaysia.<br>
                Tel: (05) 242-7777<br>
                Fax: (603) 242-5845<br>
                sales@ritzgardenhotel.com<br>
                lily@ritzgardenhotel.com<br>
    
</div>