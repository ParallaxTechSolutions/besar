Click here to reset your password: {{ url($reset_link) }}
