<div style="margin:15px">
    <h4>Dear {{$to_name}},</h4>

    <p>Please <a href="{{ url($reset_link) }}">Click Here</a> to reset your password.<br/></p>
    <br>
    <img alt="logo" src="{{$logo_link}}">



    <p>Thank you,</p>
    Best regards,<br>
    Tower Regency Hotel And Apartments Online Registration Manager<br>
    Tower Regency Hotel And Apartments<br>
    6, Jalan Dato Seri Ahmad Said, 30450 Ipoh, Perak, Malaysia.<br>
    Tel: (05) 208-6888<br>
    Fax: (603) 255-8399<br>
    inquiry@towerregency.com.my<br>

</div>
