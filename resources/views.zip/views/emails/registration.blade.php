<div style="margin:15px">
    <h4>Dear {{$formData['billing_first_name']}},</h4>

    <p>This is to confirm on your successful registration with Tower Regency Hotel And Apartments.<br/></p>
<br>
    <img alt="logo" src="{{$formData['url']}}">

    
    
    <p>Thank you,</p>
    Best regards,<br>
    Tower Regency Hotel And Apartments Online Registration Manager<br>
    Tower Regency Hotel And Apartments<br>
    6, Jalan Dato Seri Ahmad Said, 30450 Ipoh, Perak, Malaysia.<br>
    Tel: (05) 208-6888<br>
    Fax: (05) 255-8399<br>
    inquiry@towerregency.com.my<br>

</div>