@extends('front/templateFront')
@section('content')

    @include('front/about_us/about_us')

@endsection
