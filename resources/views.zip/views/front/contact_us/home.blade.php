@extends('front/templateFront')
@section('content')

    @include('front/contact_us/contact_us')

@endsection