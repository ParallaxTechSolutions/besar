@extends('front/templateFront')
@section('content')

    @include('front/dining/dining')

@endsection
