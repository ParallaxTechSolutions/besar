@extends('front/templateFront')
@section('content')

    @include('front/events_meetings/events_meetings')

@endsection