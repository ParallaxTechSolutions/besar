@extends('front/templateFront')
@section('content')

    @include('front/facilities/facilities') 

@endsection