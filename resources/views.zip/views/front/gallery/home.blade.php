@extends('front/templateFront')
@section('content')

    @include('front/gallery/gallery')

@endsection