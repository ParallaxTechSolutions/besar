
{!! html_entity_decode($index_second[0]) !!}
