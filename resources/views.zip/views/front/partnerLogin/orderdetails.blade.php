`<?php
$p=DB::table('paymentMethods')->get();
$TaxRate='';
$isReverseCalculated=false;
foreach($orderTax->products as $orderProduct){
    $roomCode=($orderProduct->product_code)?$orderProduct->product_code:$orderProduct->room_code;
    $BRoom=DB::table('products')->where('room_code',$roomCode)->first();
//    if($BRoom->reverse_tax_calculation=='1'){
//        $isReverseCalculated=true;
//    }
}
if($isReverseCalculated){
    $TaxRate=DB::table('gst_rates')->get();
    /* print_r($TaxRate);
    exit; */
}
function reverseCalculation($totalBill,$TaxRate){
    return $totalBill/(1+intval($TaxRate[0]->rate)/100);
}


//dd($order, $orderTax);
?>
@extends('front/templateFront')

@section('content')
    <style>
        .custom-strong{
            font-weight: 600;
            font-size: 20px;
        }
        .control-label
        {
            text-align: left !important;
        }
    </style>
    <?php
    //$ordersModel = new App\Http\Models\Admin\Orders();
    //$orderTax = $ordersModel->getOrderTax($userOrderDetails[0]->id);

    ?>
    <div class="room-single-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-full-width">
                    <div class="section-title-area text-center">
                        <h2 class="section-title">Booking Details</h2>
                        <p class="section-title-dec">View your booking details and track your booking.</p>
                    </div><!--/.section-title-area-->
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 room-single-content">
                    <div class="single-room list mobile-extend">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right">
                                    <a href="javascript:window.print()" class="btn btn-default">PRINT THIS PAGE &nbsp;<i class="fa fa-print"></i></a> &nbsp;
                                    <button data-toggle="modal" data-target="#email-modal" class="btn btn-default">EMAIL &nbsp;<i class="fa fa-envelope"></i></button>
                                </div>
                                <div class="clearfix"></div>
                                <div class="alert alert-success alert-dismissable margin-top" id="email-success" style="display:none;">
                                    <button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button>
                                    <i class="fa fa-check-circle"></i> <strong>Success!</strong>
                                    <p></p>
                                </div>



                                <div class="table-responsive margin-top">
                                    <?php

                                    $gst = 0;
                                    foreach($orderProducts as $orderProduct) {
                                        // $product = DB::table('products')->where('id', $orderProduct->product_id)->first();
                                        // $price = $orderProduct->amount;
                                        // $tax = 0;
                                        // if ($product and $product->is_tax) {
                                        // $tax = round($price * 0.06, 2);
                                        $gst += $orderProduct->gst;
                                        // }
                                    }
                                    //dd($userOrderDetails);
                                    ?>
                                    <table class="table cart-table" style="margin-bottom: 20px !important;">
                                        <thead>
                                        <tr>
                                            <th class="table-title">Booking ID</th>
                                            <th class="table-title">Payment Reference No.</th>
                                            <th class="table-title">Date</th>
                                            <th class="table-title">Order Total</th>
                                            <th class="table-title">Payment Method</th>
                                            <th class="table-title">Booking Status</th>
                                            <th class="table-title">Payment Status</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <tr>
                                            <td>#{{$userOrderDetails[0]->id}}</td>
                                            <td><?php echo $userOrderDetails[0]->order_id;?></td>
                                            <td><?php echo date('dS M, Y', strtotime($userOrderDetails[0]->modifydate));?></td>

                                            {{--<td>RM  {{ number_format($orderTax->subtotal - $orderTax->discount + $gst,2) }}</td>--}}
                                            <td>RM  {{ number_format($orderTax->totalPrice, 2) }}</td>

                                            </td>
                                            <td><?php echo $userOrderDetails[0]->payment_method;?></td>
                                            <td class="text-uppercase">
                                                @if($userOrderDetails[0]->status == 'Processing')
                                                    <span class="highlight fourth-color text-12px">Processing</span>
                                                @elseif($userOrderDetails[0]->status == 'New Order')
                                                    <span class="highlight orange-color text-12px">New Order</span>
                                                @elseif($userOrderDetails[0]->status == 'Ready To Ship')
                                                    <span class="highlight fourth-color text-12px">Ready To Ship</span>
                                                @elseif($userOrderDetails[0]->status == 'Shipped')
                                                    <span class="highlight blue-color text-12px">Shipped</span>
                                                @elseif($userOrderDetails[0]->status == 'Completed')
                                                    <span class="highlight first-color text-12px">Completed</span>
                                                @elseif($userOrderDetails[0]->status == 'Declined')
                                                    <span class="highlight third-color text-12px">Declined</span>
                                                @elseif($userOrderDetails[0]->status == 'Cancelled')
                                                    <span class="highlight black-color text-12px">Cancelled</span>
                                                @else
                                                    <span class="highlight black-color text-12px">New Order</span>
                                                @endif
                                                <a  data-target="#modal-status-edit" data-toggle="modal" style="float: right; padding-top: 30%" class="statusChanged"><i class="fa fa-edit"></i></a>
                                                    {{--Change fullfilled Status--}}
                                                    <div class="modal fade" id="modal-status-edit" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                                    <h4 id="modal-login-label2" class="modal-title">Update Order</h4>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form">
                                                                        <form class="form-horizontal" id="updateOrderStatusFulfil">
                                                                            <input type="hidden" id="orderStatusId" value="{{@($userOrderDetails[0]->order_id)}}" name="order_id">
                                                                            <div class="form-group">
                                                                                <label class="col-md-12 control-label">Select To Update</label>
                                                                                <div class="col-md-12">
                                                                                    <select name="fulfilmentStatus" id="fulfilmentStatus" class="form-control">
                                                                                        <option @if $userOrderDetails[0]->status == 'Processing' value="Confirmed">Confirmed</option>
                                                                                        <option value="Confirmed">Confirmed</option>
                                                                                        <option value="Cancel">Cancel</option>
                                                                                        <option value="Pending">Pending</option>
                                                                                        <option value="Fulfilled">Fulfilled</option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-12 control-label">Fulfilled Date </label>
                                                                                <div class="col-md-12">
                                                                                    <div class="input box-radius"><i class="fa fa-calendar"></i>
                                                                                        <input type="text" id="datePick" name="date" placeholder="Enter New Date"class="form-control">
                                                                                    </div>

                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label class="col-md-12 control-label">Fulfilled Time
                                                                                </label>
                                                                                <div class="col-md-12">
                                                                                    <input type='text' name="time" style="width:100%" placeholder="Time" id="timePick"   class="form-control bs-timepicker">
                                                                                </div>
                                                                            </div>

                                                                            <div style="float: right" class="form-actions form-group">
                                                                                <button type="submit" id="save-booking-status" class="btn btn-default">Save &nbsp;<i class="fa fa-floppy-o"></i></button>&nbsp;
                                                                            </div>
                                                                            <div class="clearfix"></div>
                                                                            <input type="hidden" name="_token"
                                                                                   value="{{ csrf_token() }}">
                                                                        </form>
                                                                    </div>
                                                                </div>

                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div>

                                            </td>
                                            <td class="text-uppercase">
                                                @if($userOrderDetails[0]->payment_status == 'Paid')
                                                    <span class="highlight first-color text-12px text-uppercase">Paid</span>
                                                @elseif($userOrderDetails[0]->payment_status == 'Processing')
                                                    <span class="highlight fourth-color text-12px text-uppercase">Processing</span>
                                                @elseif($userOrderDetails[0]->payment_status == 'Payment Error')
                                                    <span class="highlight third-color text-12px">Payment Error</span>
                                                @elseif($userOrderDetails[0]->payment_status == 'Cancelled')
                                                    <span class="highlight black-color text-12px text-uppercase">Cancelled</span>
                                                @endif
                                                <a  data-target="#modal-payment-edit" data-toggle="modal" style="float: right; padding-top: 30%" class="statusChanged"><i class="fa fa-edit"></i></a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="clearfix margin-top"></div>
                            </div>
                        </div>
                        @if(count($packages) > 0)
                            <div class="table-responsive margin-top package">
                                <table class="table">
                                    <tr>
                                        <td style="width:50%">
                                            <ul style="text-align: left;">
                                                <li>Pick Up:<span class="text-black info-property"><b>{{$propertyName}}</b></span></li>
                                                <li>Drop Off: <span class="text-black"><b>{{ date('dS M, Y', strtotime($userOrderDetails[0]->check_date->date_checkin)) }} </b></span></li>
                                                <li>Date:  <span class="text-black"><b>{{ date('dS M, Y', strtotime($userOrderDetails[0]->check_date->date_checkout)) }} </b></span></li>
                                                <li>Time: <span class="text-black"><b>{{ $userOrderDetails[0]->rooms }}</b></span></li>
                                                <li>Adults: <span class="text-black"><b>{{ $userOrderDetails[0]->adults }}</b></span></li>
                                                <li>Children: <span class="text-black"><b>{{ $userOrderDetails[0]->children }}</b></span>
                                                    <a style="float:right; " data-target="#modal-edit" data-toggle="modal"><i class="fa fa-edit"></i></a>
                                                </li>
                                            </ul>
                                        </td>
                                        <td style="width:50%">
                                            <ul style="text-align: left;">
                                                <li>Package Name: <span class="text-black"><b>{{$packages[0]->package_name}}</b></span></li>
                                                <li>Package Code: <span class="text-black"><b>{{$packages[0]->package_code}}</b></span></li>
                                                <li>Value Added Services:
                                                    @foreach(explode(",",$packages[0]->value_added_service) as $service)
                                                        <br>
                                                        <span class="text-black"><b>&gt;&gt; {{ $service }}</b></span>
                                                    @endforeach
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        @else

                            <div class="row">
                                <div class="col-md-12">
                                    Pick Up: <span class="text-black info-property"><b>{{$propertyName}}</b></span>
                                </div>
                                @if( ! empty($userOrderDetails[0]->check_date))
                                    <div class="col-md-12">
                                        Drop Off: <span class="text-black"><b>{{ date('dS M, Y', strtotime($userOrderDetails[0]->check_date->date_checkin)) }}</b></span>
                                    </div>
                                @endif
                                @if( ! empty($userOrderDetails[0]->check_date))
                                    <div class="col-md-12">
                                        Date: <span class="text-black"><b>{{ date('dS M, Y', strtotime($userOrderDetails[0]->check_date->date_checkout)) }}</b></span>
                                    </div>
                                @endif
                                @if( ! empty($userOrderDetails[0]->rooms))
                                    <div class="col-md-12">
                                        Time: <span class="text-black"><b>{{ $userOrderDetails[0]->rooms }}</b></span>
                                    </div>
                                @endif
                                @if( ! empty($userOrderDetails[0]->adults))
                                    <div class="col-md-12">
                                        Adults: <span class="text-black"><b>{{ $userOrderDetails[0]->adults }}</b></span>
                                    </div>
                                @endif
                                <div class="col-md-11">
                                    Children: <span class="text-black"><b>{{ $userOrderDetails[0]->children }}</b></span>
                                </div>
                                <div class="col-md-1">
                                    <span id="modalPopup"><i class="fa fa-edit"></i></span>
                                </div>
                            </div>
                        @endif


                        {{--changes PickUp & Drop Off--}}
                        <div class="modal fade" id="modalPopup" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 id="modal-login-label2" class="modal-title">Update Order</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form">
                                            <form class="form-horizontal" id="edit-update-order">

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Select Pick Up Location</label>
                                                    <div class="col-md-12">
                                                        <select name="pick_up" id="pick_up" class="form-control">
                                                            @foreach($pick_up_list as $key => $val)
                                                                <option value="{{$val->property_id}}"
                                                                        {{($val->property_id ? 'selected' : '')}}>{{$val->name}}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Select Drop off Location</label>
                                                    <div class="col-md-12">
                                                        <select name="drop_off" id="drop_off" class="form-control">
                                                            @foreach($drop_off_list as $val)
                                                                <option value="{{$val->drop_list_id}}"
                                                                        {{($val->drop_list_id)}}>{{$val->name}}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Enter New Date </label>
                                                    <div class="col-md-12">
                                                        <div class="input box-radius"><i class="fa fa-calendar"></i>
                                                            <input type="text" id="date" name="date" placeholder="Enter New Date"
                                                                   class="form-control"
                                                                   value="<?php echo empty($departure) ? '' : $departure ?>">
                                                        </div>

                                                    </div>
                                                </div>


                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Enter New Time
                                                    </label>
                                                    <div class="col-md-12">
                                                        <input type='text' name="time" style="width:100%" placeholder="Time" id="time"   class="form-control bs-timepicker">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Adult </label>
                                                    <div class="col-md-12">
                                                        <select name="adult" class="form-control">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>
                                                            <option value="7">7</option>
                                                            <option value="8">8</option>
                                                            <option value="9">9</option>
                                                            <option value="10">10</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Children </label>
                                                    <div class="col-md-12">
                                                        <select name="childrens" class="form-control">
                                                            <option value="0">0</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>
                                                            <option value="7">7</option>
                                                            <option value="8">8</option>
                                                            <option value="9">9</option>
                                                            <option value="10">10</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-actions form-group">
                                                    <button type="submit" id="save-new-address" class="btn btn-default">Save &nbsp;<i class="fa fa-floppy-o"></i></button>&nbsp;
                                                </div>
                                                <div class="clearfix"></div>
                                                <input type="hidden" name="_token"
                                                       value="{{ csrf_token() }}">
                                            </form>
                                        </div>
                                    </div>

                                </div><!-- /.modal-content -->
                            </div><!-- /.modal-dialog -->
                        </div>
                         {{--changes payment status--}}
                        <div class="modal fade" id="modal-payment-edit" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 id="modal-login-label2" class="modal-title">Update Order</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form">
                                            <form class="form-horizontal" id="updatePayemntOrder">
                                                <input type="hidden" id="orderStatusId" value="{{@($userOrderDetails[0]->order_id)}}" name="order_id">

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Select To Update</label>
                                                    <div class="col-md-12">
                                                        <select name="confirmedStatus" id="confirmedStatus" class="form-control">
                                                            <option value="Pending">Pending</option>
                                                            <option value="Fulfilled">Fulfilled</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Enter Driver's name </label>
                                                    <div class="col-md-12">
                                                        <div class="input box-radius">
                                                            <input type="text" id="driver_name" name="driver_name" placeholder="Enter Driver Name"class="form-control">
                                                        </div>

                                                    </div>
                                                </div>


                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Enter car plate number
                                                    </label>
                                                    <div class="col-md-12">
                                                        <input type='text' name="car_plate" style="width:100%" placeholder="Car Plate" id="car_plate"   class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-12 control-label">Enter telephone number
                                                    </label>
                                                    <div class="col-md-12">
                                                        <input type='number' name="telephone_number" id="telephone_number" style="width:100%" placeholder="telephone number"    class="form-control">
                                                    </div>
                                                </div>
                                                <div style="float: right" class="form-actions form-group">
                                                    <button type="submit" id="PaymentOrderStatus" class="btn btn-default">Save &nbsp;<i class="fa fa-floppy-o"></i></button>&nbsp;
                                                </div>
                                                <div class="clearfix"></div>
                                                <input type="hidden" name="_token"
                                                       value="{{ csrf_token() }}">
                                            </form>
                                        </div>
                                    </div>

                                </div><!-- /.modal-content -->
                            </div><!-- /.modal-dialog -->
                        </div>


                        <hr>

                        <div class="room-info">
                            <div class="room-description clearfix">
                                <h4> Guest Details </h4>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <ul>
                                        <li><b>Guest Name:</b> <?php echo $userOrderDetails[0]->billing_first_name;?> <?php echo $userOrderDetails[0]->billing_last_name;?> </li>
                                        <li><b>Telephone:</b> <?php echo $userOrderDetails[0]->billing_telephone;?></li>
                                        <li><b>Address: </b><?php echo $userOrderDetails[0]->billing_address;?>, <?php echo $userOrderDetails[0]->billing_post_code;?> <?php echo $userOrderDetails[0]->billing_city;?>, <?php echo $userOrderDetails[0]->billing_state_name;?>, <?php echo $userOrderDetails[0]->billing_country_name;?>.</li>
                                        <li><b>Email:</b> <?php echo $userOrderDetails[0]->billing_email; ?></li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul>
                                        <li><b>Passport/NRIC:</b> </li>
                                    <!-- <li><b>Ship to:</b> <?php echo $userOrderDetails[0]->shipping_first_name;?> <?php echo $userOrderDetails[0]->shipping_last_name;?> </li> -->
                                        <li><b>Email:</b> <?php echo $userOrderDetails[0]->shipping_email;?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="room-info">
                            <div class="room-description clearfix">
                                <h4>Your Reservation Details </h4>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table checkout-table table-responsive">
                                <thead>
                                <tr>
                                    <!-- <th class="table-title">Product Id</th> -->
                                    <th class="table-title">Types</th>
                                    <th class="table-title">Vehicle Code</th>
                                    <th class="table-title">Unit Price / Night (Nett)</th>
                                    <!-- <th class="table-title">Quantity</th> -->
                                    {{-- <th class="table-title" style="text-align: right;">SST (RM)</th> --}}
                                    <th class="table-title">Subtotal</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                $gst = 0;
                                $gst_rate = 6;
                                if(isset($orderTax->products)){

                                ?>

                                @foreach($orderTax->products as $orderProduct)
                                    <?php
                                    //                                    $checkAvailModel = new App\Http\Models\Front\CheckAvail();
                                    //                                    $roomDates = $checkAvailModel->getPriceByDates($orderProduct->id, $userOrderDetails[0]->check_date->date_checkin, $userOrderDetails[0]->check_date->date_checkout);

                                    $priceByDates = "";
                                    if(!empty($roomDates[$orderProduct->id])){
                                        foreach ($roomDates[$orderProduct->id] as $pd) {
                                            if($orderTax->ota_checklist_id && isset($orderProducts[0]->amount_sold_at) && !empty($orderProducts[0]->amount_sold_at)){
                                                $pd->sale_price = $orderProducts[0]->amount_sold_at;
                                            }
                                            $priceByDates .= "<span>". date('l', strtotime($pd->date)) .", ". date('d/M/Y', strtotime($pd->date)) ." MYR " .number_format($pd->sale_price, 2)." </span><br/>";
                                        }
                                    }
                                    if($priceByDates == "") {
                                        $result = DB::table('product_room_prices')
                                            ->where('date', '>=', $userOrderDetails[0]->check_date->date_checkin)
                                            ->where('date', '<', $userOrderDetails[0]->check_date->date_checkout)
                                            ->where('product_id', $orderProduct->id)
                                            ->orderBy('date')
                                            ->get();
                                        foreach ($result as $pd) {
                                            if($orderTax->ota_checklist_id && isset($orderProducts[0]->amount_sold_at) && !empty($orderProducts[0]->amount_sold_at)){
                                                $pd->sale_price = $orderProducts[0]->amount_sold_at;
                                            }
                                            $priceByDates .= "<span>". date('l', strtotime($pd->date)) .", ". date('d/M/Y', strtotime($pd->date)) ." MYR " .number_format($pd->sale_price, 2)." </span><br/>";
                                        }
                                    }
                                    ?>
                                    <tr>
                                    <!-- <td class="item-code">{{ $orderProduct->id }}</td> -->
                                        <td class="item-name-col">
                                            <figure><a href="{{ url('web88cms/products/editProduct/' . $orderProduct->product_id) }}">

                                                    {{--   <img src="{{ asset('/public/admin/products/medium/' . $orderProduct->thumbnail_image_1) }}" alt="{{ $orderProduct->type }}" class="img-responsive"> --}}

                                                    @if($orderProduct->product_thumb != null)
                                                        <img src="{{ asset('/public/admin/products/medium/' . $orderProduct->product_thumb) }}" alt="{{ $orderProduct->product_type }}" class="img-responsive">
                                                    @else
                                                        <img src="{{ asset('/public/admin/products/medium/' . $orderProduct->thumbnail_image_1) }}" alt="{{ $orderProduct->type }}" class="img-responsive">
                                                    @endif
                                                </a>
                                                @if($orderProduct->product_promo_behaviour != null)
                                                    @if($orderProduct->product_promo_behaviour === 'sale')
                                                        <img class="promo" src="{{ asset('public/promo/sale_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'hot')
                                                        <img class="promo" src="{{ asset('public/promo/hot_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'new')
                                                        <img class="promo" src="{{ asset('public/promo/new_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'pwp')
                                                        <img class="promo" src="{{ asset('public/promo/pwp_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'last_minute')
                                                        <img class="promo" src="{{ asset('public/promo/last_minute.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === '24hoursale')
                                                        <img class="promo" src="{{ asset('public/promo/24hour_sale.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'popular')
                                                        <img class="promo" src="{{ asset('public/promo/popular.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'early_bird')
                                                        <img class="promo" src="{{ asset('public/promo/early_bird.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">

                                                    @elseif($orderProduct->product_promo_behaviour === 'black_friday')
                                                        <img class="promo" src="{{ asset('public/promo/black_friday.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'singles_day')
                                                        <img class="promo" src="{{ asset('public/promo/singles_day.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'merdeka')
                                                        <img class="promo" src="{{ asset('public/promo/merdeka.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->product_promo_behaviour === 'valentines')
                                                        <img class="promo" src="{{ asset('public/promo/valentine.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">


                                                    @endif
                                                @else
                                                    @if($orderProduct->promo_behaviour === 'sale')
                                                        <img class="promo" src="{{ asset('public/promo/sale_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'hot')
                                                        <img class="promo" src="{{ asset('public/promo/hot_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'new')
                                                        <img class="promo" src="{{ asset('public/promo/new_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'pwp')
                                                        <img class="promo" src="{{ asset('public/promo/pwp_label.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'last_minute')
                                                        <img class="promo" src="{{ asset('public/promo/last_minute.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === '24hoursale')
                                                        <img class="promo" src="{{ asset('public/promo/24hour_sale.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'popular')
                                                        <img class="promo" src="{{ asset('public/promo/popular.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'early_bird')
                                                        <img class="promo" src="{{ asset('public/promo/early_bird.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">


                                                    @elseif($orderProduct->promo_behaviour === 'black_friday')
                                                        <img class="promo" src="{{ asset('public/promo/black_friday.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'singles_day')
                                                        <img class="promo" src="{{ asset('public/promo/singles_day.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'merdeka')
                                                        <img class="promo" src="{{ asset('public/promo/merdeka.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">
                                                    @elseif($orderProduct->promo_behaviour === 'valentines')
                                                        <img class="promo" src="{{ asset('public/promo/valentine.png') }}" style="width: 35px !important;height: 35px !important;position: relative !important;top: -86px !important;left: 30px !important;">



                                                    @endif
                                                @endif



                                            </figure>


                                            <header class="item-name">
                                                {{-- <a href="{{ url('web88cms/products/editProduct/' . $orderProduct->product_id) }}">{{ $orderProduct->type }}</a> --}}
                                                @if($orderProduct->product_type != null)
                                                    <a href="{{ url('web88cms/products/editProduct/' . $orderProduct->product_id) }}">{{ $orderProduct->product_type }}</a>
                                                @else
                                                    <a href="{{ url('web88cms/products/editProduct/' . $orderProduct->product_id) }}">{{ $orderProduct->type }}</a>
                                                @endif

                                            </header>
                                            <ul class="product--type">
                                                <li><i class="fa fa-bed"></i> <b>BED:</b> {{ ($orderProduct->product_bed)?$orderProduct->product_bed:$orderProduct->bed }} </li>
                                                <li><i class="fa fa-user"></i> <b>GUEST:</b> {{ ($orderProduct->product_guest)?$orderProduct->product_guest:$orderProduct->guest }}</li>
                                                <li><i class="fa fa-cutlery"></i> <b>MEAL: {{ ($orderProduct->product_meal)?$orderProduct->product_meal:$orderProduct->meal }}</b> </li>
                                                @if($orderTax->ota_checklist_id)
                                                    <li class="lowest-price"><i class="fa  fa-dot-circle-o"></i> <b>Lowest price available</b> </li>
                                                @endif

                                            </ul>
                                            <ul>
                                                @if($orderProduct->color_name)
                                                    <li>Color: {{ $orderProduct->color_name }}</li>
                                                @endif

                                                @if($orderProduct->event_type)
                                                    <li><i class="fa fa-gift text-red"></i> <span class="text-red"><b>For: {{ $orderProduct->event_type }}</b></span></li>
                                                @endif
                                            </ul>

                                            @if (!is_null($orderProduct->pwp_price))
                                                <span class="pwp-item">PWP ITEM</span>
                                            @endif
                                        </td>
                                        <td class="item-price-col text-center">{{ ($orderProduct->product_code)?$orderProduct->product_code:$orderProduct->room_code }}</td>
                                        <td class="item-price-col">
                                        {!! $priceByDates !!}
                                        <!-- @if (is_null($orderProduct->pwp_price))
                                            {{ number_format($orderProduct->amount, 2) }}
                                        @else
                                            {{ number_format($orderProduct->pwp_price, 2) }}
                                        @endif -->
                                        </td>
                                    <!-- <td class="item-price-col text-center">{{ $orderProduct->quantity }}</td> -->
                                        {{--   <td class="item-price-col" style="text-align:right;padding-right:10px">{{ number_format($orderProduct->tax, 2) }}</td> --}}
                                        <?php $sbttl = $orderTax->subtotal * $orderTax->rooms; ?>

                                        <td class="item-price-col"><!--{{ number_format($orderTax->totalPrice, 2) }}-->{{ ($isReverseCalculated)?number_format(reverseCalculation($sbttl,$TaxRate), 2):number_format((float)$sbttl, 2, '.', '') }}{{-- {!! number_format($sbttl, 2) !!} --}}</td>
                                        <?php
                                        $gst_rate = $orderProduct->gst_rate;
                                        $gst += (( $sbttl * $gst_rate)/100);
                                        ?>
                                    </tr>
                                @endforeach
                                <?php } ?>

                                <tr>
                                    <td class="checkout-table-title text-right" colspan="2"></td>
                                    <td colspan="1" class="checkout-table-title text-black">
                                        <span class="alignleft">SUBTOTAL:</span>
                                    </td>
                                    <td style="text-align:right; padding-right: 10px" class="checkout-table-price text-black">RM {{ ($isReverseCalculated)?number_format(reverseCalculation($sbttl,$TaxRate), 2):number_format((float)$sbttl, 2, '.', '') }}{{-- {!! number_format($sbttl, 2) !!} --}}</td>
                                </tr>
                                @if($isReverseCalculated)
                                    <tr>
                                        <td class="checkout-table-title text-right" colspan="2"></td>
                                        <td class="checkout-table-title text-black"><span class="alignleft">{{$TaxRate[0]->name}} ({{ $TaxRate[0]->rate }}%)</span></td>
                                        <td class="checkout-table-price text-black"> <span
                                                    class="item-price-special alignright">RM {{ ($isReverseCalculated)?number_format($sbttl-reverseCalculation($sbttl,$TaxRate), 2):'0.00' }}</span></td>
                                    </tr>
                                @endif

                                <tr>
                                    <td class="checkout-table-title text-right" colspan="2"></td>
                                    <td class="text-danger checkout-table-title" colspan="1">
                                        <span class="alignleft">DISCOUNT:</span>
                                    </td>
                                    <td style="text-align:right; padding-right: 10px;" class="text-danger checkout-table-title">RM {{ number_format($orderTax->discount, 2) }}</td>
                                </tr>
                                @if($gst > 0)
                                    <tr>
                                        <td class="checkout-table-title text-right" colspan="2"></td>
                                        <td class="checkout-table-title text-black" colspan="1">
                                            <?php
                                            $tax_details = @explode(',',$orderTax->tax_name);
                                            ?>
                                            <span class="alignleft">{{@$tax_details[0]}} ({{ @$tax_details[1] }}%):</span>
                                        </td>
                                        <!-- <td style="border: none;"></td> -->
                                        <td style="text-align:right; padding-right: 10px" class="checkout-table-title text-black">RM {{ number_format($gst, 2) }}</td>
                                    </tr>
                                @endif
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td class="checkout-table-title text-right" colspan="2"></td>
                                    <td  colspan="1" class="checkout-table-title">
                        <span class="alignleft">
                            <b>TOTAL:</b>
                        </span>
                                    </td>
                                <?php $totalAmount = (($sbttl + $gst) - $orderTax->discount ); ?>
                                <!-- <td style="text-align:right;padding-right:10px"><b>{{ number_format($orderTax->tax + $orderTax->shipping_charge * 0.06, 2) }}</b></td> -->
                                    <td  style="text-align:right; padding-right: 10px" class="checkout-total-price cart-total"><b>RM {{ number_format($totalAmount,2) }}</b></td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="hidden-md hidden-lg text-center extend-btn"><span class="extend-icon"><i class="fa fa-angle-down"></i></span></div>
                </div>
            </div>

            <div class="row result-container">
                <div class="col-md-12 review-comment-form box-radius" style="padding:15px;">
                    <h4>Special Requests</h4>
                    <p>Please write requests in English or the property's language</p>
                    <textarea class="form-control" name="special_requests" id="special_requests" rows="5" readonly><?php echo $userOrderDetails[0]->special_requests; ?></textarea>
                    <div class="clearfix"></div><br/>
                    <div class="alert alert-warning" role="alert">
                        <strong>Note:</strong> Don't disclose any additional personal or payment information in your request.
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="single-room list mobile-extend">
                        <div class="room-info">
                            <div class="room-description clearfix">

                                @if(isset($orderProduct->terms_and_conditions))
                                    <h4 class="text-uppercase">Terms and Conditions</h4>
                                    <?php echo $orderProduct->terms_and_conditions; ?>
                                @endif

                                @if(isset($orderProduct->cancellation_policy))
                                    <h4 class="margin-top">Cancellation Policy</h4>
                                    <?php echo $orderProduct->cancellation_policy; ?>
                                @endif

                                <div class="clearfix"></div>

                                <hr>

                                <div class="text-center">
                                    <a href="/dashboard" class="btn btn-default btn-sm">Back</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="email-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" style="clear:none">Enter Email Address</h4>
                </div>
                <div class="modal-body">
                    Enter an email address you want to email the invoice to.
                    <input type="email" placeholder="Email Address" class="form-control" id="email-address">
                    <p class="text-danger" id="email-error" style="display: none; margin-bottom: 10px;"></p>
                </div>

                <div class="modal-footer" style="text-align: right;">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="font-size: 12px; padding: 10px">Close</button>
                    <button type="button" class="btn btn-default" style="font-size: 12px; padding: 10px;" id="btn-send-email">Send</button>
                </div>


            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

@endsection



@section('scripts')

    <script type="text/javascript">
        $(function () {
            $('.bs-timepicker').timepicker();
        });
        $(function () {
            $('#timePick').timepicker();
        });

        jQuery(document).on('click', '#email-modal #btn-send-email', function(){
            btn = jQuery(this);
            orderDetails = ({!! json_encode($userOrderDetails) !!});
            orderProducts = {!! json_encode($orderProducts) !!};
            if(jQuery("#email-modal #email-address").val() == ""){
                jQuery("#email-modal #email-error").css('display', 'block');
                jQuery("#email-modal #email-error").html("Please enter an email address.");
            }else{
                jQuery("#email-modal #email-error").css('display', 'none');
                jQuery(this).attr('disabled', true);

                jQuery.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                jQuery.ajax({
                    type: "POST",
                    url: "/user/sendOrderEmail",
                    data: {invoice: {orderDetail: orderDetails, orderProducts: orderProducts}, email: jQuery("#email-modal #email-address").val()},
                    dataType: 'JSON',


                    success: function(response){
                        if(response.success){
                            jQuery('#email-success').css('display', 'block');
                            jQuery('#email-success p').html(response.success + " to " + jQuery('#email-modal #email-address').val());
                        }
                        console.log(response);
                    },

                    complete:function(){
                        jQuery('#email-modal').modal('toggle');
                        // jQuery("#email-modal #email-address").val("");
                        btn.removeAttr('disabled');

                    }
                });


            }
        });

        jQuery(document).on('submit', '#edit-update-order', function(){
            var btn = jQuery(this);
            var data = {
                pick_up: jQuery("#pick_up").val(),
                drop_off: jQuery("#drop_off").val(),
                date: jQuery("#date").val(),
                time: jQuery('#time').val(),
                partner_id: <?php echo Auth::user()->id; ?> ,
                order_id: <?php echo $userOrderDetails[0]->order_id;?> ,
            };

            jQuery.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            jQuery.ajax({
                type: "POST",
                url: "/user/update-new-address",
                data: data,
                dataType: 'JSON',
                success: function(response){
                    if(response.success){
                        jQuery('#email-success').css('display', 'block');
                        jQuery('#email-success p').html(response.success + " order has been changed ");
                    }
                    console.log(response);
                },

                complete:function(){
                    jQuery('#email-modal').modal('toggle');
                    btn.removeAttr('disabled');
                }
            });
        });

        jQuery(document).on('submit', '#updateOrderStatusFulfil', function(){
            var btn = jQuery(this);
            var data = {
                date: jQuery("#datePick").val(),
                time: jQuery('#timePick').val(),
                status: jQuery('#fulfilmentStatus').val(),
                order_id: jQuery('#orderStatusId').val(),
            };

            jQuery.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            jQuery.ajax({
                type: "POST",
                url: "{{url('partner-client-status-update')}}",
                data: data,
                dataType: 'JSON',
                success: function(response){
                    if(response.success){
                        jQuery('#email-success').css('display', 'block');
                        jQuery('#email-success p').html(response.success + " order status has been changed ");
                    }
                    console.log(response);
                },

                complete:function(){
                    jQuery('#email-modal').modal('toggle');
                    btn.removeAttr('disabled');
                }
            });
        });

        jQuery(document).on('submit', '#updatePayemntOrder', function(){
            var btn = jQuery(this);
            var data = {
                driver_name: jQuery("#driver_name").val(),
                car_plate: jQuery('#car_plate').val(),
                status: jQuery('#confirmedStatus').val(),
                telephoneNumber: jQuery('#telephone_number').val(),
                order_id: jQuery('#orderStatusId').val(),
            };

            jQuery.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            jQuery.ajax({
                type: "POST",
                url: "{{url('partner-client-payment-status-update')}}",
                data: data,
                dataType: 'JSON',
                success: function(response){
                    if(response.success){
                        jQuery('#email-success').css('display', 'block');
                        jQuery('#email-success p').html(response.success + " Payment status has been changed ");
                    }
                    console.log(response);
                },

                complete:function(){
                    jQuery('#email-modal').modal('toggle');
                    btn.removeAttr('disabled');
                }
            });
        });


        jQuery('#datePick').pignoseCalendar({
            buttons: true,
            minDate: new Date(),
            select: function (dates, context) {
            },
            apply: function (date, context) {
                if (new Date(jQuery('#date-arrival').val()) >= new Date(date)) {
                    jQuery('#modal-validation').modal('show');
                    jQuery('#modal-check-ota').hide()
                }
            }
        });

    </script>
@endsection
`