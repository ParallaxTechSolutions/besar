<ul class="margin-top category-filter-list jscrollpane">
    <li>   <a href="{{url('partnerDashboard')}}">      Account Dashboard</a></li>
    <li>     <a href="{{ url('partner-account-edit') }}">    Account Information</a></li>
    <li>     <a href="{{ url('partner/order-history') }}">   My Orders</a></li>
    <li>     <a href="{{ url('wishlist') }}">       My Wishlist</a></li>
    <li>     <a href="{{ url('/events') }}">        My Special List</a></li>
</ul>