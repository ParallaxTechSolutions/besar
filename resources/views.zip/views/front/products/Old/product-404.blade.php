@extends('front/templateFront')

@section('content')
	
Product not found
@endsection