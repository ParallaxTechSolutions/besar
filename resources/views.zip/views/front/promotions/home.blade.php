@extends('front/templateFront')
@section('content')

    @include('front/promotions/promotions')

@endsection
