@extends('front/templateFront')
@section('content')

    @include('front/rooms_suites/rooms_suites');

@endsection
