


<ul class="margin-top category-filter-list jscrollpane">
                           
                           
     <li>   <a href="{{ url('dashboard') }}">      Account Dashboard</a></li>
    <li>     <a href="{{ url('accountedit') }}">    Account Information</a></li>
    <li>     <a href="{{ url('billingaddress') }}"> Billing Information</a></li>
    <li>     <a href="{{ url('shippingaddress') }}">Shipping Information</a></li>
    <li>     <a href="{{ url('orderhistory') }}">   My Orders</a></li>
    <li>     <a href="{{ url('wishlist') }}">       My Wishlist</a></li>
    <li>     <a href="{{ url('/events') }}">        My Special List</a></li>

                           
                           
                           	<?php /*?><li> <a href="dashboard.html">Account Dashboard</a></li>
                            <li> <a href="account_edit.html">Account Information</a></li>
                            <li> <a href="order_history_list.html">My Bookings</a></li>
       <?php */?>                  </ul>