@extends('front/templateFront')
@section('content')

    @include('front/wedding/wedding')

@endsection